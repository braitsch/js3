{\rtf1\ansi\ansicpg1252\cocoartf1038\cocoasubrtf360
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww9000\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\ql\qnatural\pardirnatural

\f0\fs24 \cf0 \ul \ulc0 JS3 Quick-Start & Example Bundle\ulnone \
\
Open index.html in your favorite text editor and comment / uncomment any of the script tags to run one of the examples in a browser window.\
\
Online docs and source code at {\field{\*\fldinst{HYPERLINK "http://js3.quietless.com/"}}{\fldrslt http://js3.quietless.com/}}}